package mailServer;
public interface IContact {
}
