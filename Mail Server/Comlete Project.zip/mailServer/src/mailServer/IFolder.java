package mailServer;

public interface IFolder {

}
