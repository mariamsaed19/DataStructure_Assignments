package mailServer;

public interface IMail {

}
