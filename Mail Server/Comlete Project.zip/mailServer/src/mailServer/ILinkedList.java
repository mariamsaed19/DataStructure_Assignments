package mailServer;

public class ILinkedList {

}
