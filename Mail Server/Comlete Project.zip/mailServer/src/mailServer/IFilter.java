package mailServer;

public interface IFilter {

}
