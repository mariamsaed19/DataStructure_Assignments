package mailServer;

public interface ISort {

}
